$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            "X-App-Key": "dipr",
            "X-App-Name": "dipr"
        }
    }); //check
}); //check
